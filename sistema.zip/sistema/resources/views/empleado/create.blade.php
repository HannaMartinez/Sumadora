Formulario de creación de jugadores
<form action="{{ url('/empleado') }}" method="post" enctype="multipart/form-data">
@csrf


<label for="Foto"> Foto </label>
<input type="file" name="Foto" id="Foto" >
<br>

<label for="Nombre Completo"> Nombre Completo </label>
<input type="text" name="Nombre" size= "30"id="Nombre" >
<br>

<label for="NickName"> Nick Name  </label>
<input type="text" name="ApellidoPaterno" id="ApellidoPaterno">
<br>

<label for="ApellidoMaterno"> Edad </label>
<input type="text" name="ApellidoMaterno" id="ApellidoMaterno" >
<br>

<label for="Correo"> Numero </label>
<input type="text" name="Correo" id="Correo" >
<br>
 
<label for="posicion"> posición </label>
<<input  type="text" name="posicion" id="posicion">
<br>


<input type="submit" value="Guardar Datos" >
<br>

</form>